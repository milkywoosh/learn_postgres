--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE projek_apl;
--
-- Name: projek_apl; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE projek_apl WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE projek_apl OWNER TO postgres;

\connect projek_apl

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    id integer NOT NULL,
    account character varying(15),
    name character varying(30)
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.clients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.clients_id_seq OWNER TO postgres;

--
-- Name: clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.clients_id_seq OWNED BY public.clients.id;


--
-- Name: mega_cgk000504; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mega_cgk000504 (
    id integer NOT NULL,
    awb character varying(30) NOT NULL,
    pelanggan character varying(100) NOT NULL,
    penerima character varying(100) NOT NULL,
    tlp1 character varying(20) DEFAULT NULL::character varying,
    no_referensi text,
    tanggal date NOT NULL,
    tlc_tujuan character varying(3) NOT NULL,
    tujuan character varying(90) NOT NULL,
    ktp character varying(2) DEFAULT 'X'::character varying,
    kirim_ke_client date,
    status_pod character varying(12) NOT NULL,
    kasus text DEFAULT 'X'::text,
    keterangan text DEFAULT 'X'::text,
    tanggal_terima date NOT NULL,
    wilayah character varying(20) NOT NULL
);


ALTER TABLE public.mega_cgk000504 OWNER TO postgres;

--
-- Name: mega_cgk000504_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mega_cgk000504_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mega_cgk000504_id_seq OWNER TO postgres;

--
-- Name: mega_cgk000504_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mega_cgk000504_id_seq OWNED BY public.mega_cgk000504.id;


--
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_id_seq'::regclass);


--
-- Name: mega_cgk000504 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mega_cgk000504 ALTER COLUMN id SET DEFAULT nextval('public.mega_cgk000504_id_seq'::regclass);


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (id, account, name) FROM stdin;
\.
COPY public.clients (id, account, name) FROM '$$PATH$$/3588.dat';

--
-- Data for Name: mega_cgk000504; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mega_cgk000504 (id, awb, pelanggan, penerima, tlp1, no_referensi, tanggal, tlc_tujuan, tujuan, ktp, kirim_ke_client, status_pod, kasus, keterangan, tanggal_terima, wilayah) FROM stdin;
\.
COPY public.mega_cgk000504 (id, awb, pelanggan, penerima, tlp1, no_referensi, tanggal, tlc_tujuan, tujuan, ktp, kirim_ke_client, status_pod, kasus, keterangan, tanggal_terima, wilayah) FROM '$$PATH$$/3586.dat';

--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clients_id_seq', 4, true);


--
-- Name: mega_cgk000504_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mega_cgk000504_id_seq', 1122, true);


--
-- Name: mega_cgk000504 mega_cgk000504_awb_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mega_cgk000504
    ADD CONSTRAINT mega_cgk000504_awb_key UNIQUE (awb);


--
-- Name: mega_cgk000504 mega_cgk000504_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mega_cgk000504
    ADD CONSTRAINT mega_cgk000504_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

